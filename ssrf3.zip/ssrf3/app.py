from flask import Flask, request, send_file
import pdfkit

app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    return '''
    <html>
        <head>
            <title>HTML to PDF Converter</title>
        </head>
        <body>
            <h1>HTML to PDF Converter</h1>
            <form action="/generate_pdf" method="post">
                <textarea name="html" rows=10 cols=100 ></textarea>
                <input type="submit" value="Generate PDF">
            </form>
        </body>
    </html>
    '''


@app.route('/s2dYNF08aG5176SAzVVpGwpiL3BQ39', methods=['GET'])
def hidden():
    return '''
    <html>
        <head>
            <title>Secret</title>
        </head>
        <body>
            ssrf{c5918b665934175e4296535e43d0e840ba037c61}
        </body>
    </html>
    '''

def sanitize_user_input(input_str):
    return input_str.replace("<script>", "").replace("</script>", "")

@app.route('/generate_pdf', methods=['POST'])
def generate_pdf():
    html_content = request.form.get('html')
    sanitized_html = sanitize_user_input(html_content)
    if ("localhost" in sanitized_html or "127.0.0.1" in sanitized_html or "0.0.0.0" in sanitized_html):
        pdfkit.from_string("Naughty naughty", 'output.pdf', options={'enable-local-file-access': True})
    else:
        pdfkit.from_string(sanitized_html, 'output.pdf', options={'enable-local-file-access': True})
    
    
    return send_file('output.pdf', as_attachment=True)

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=False)


