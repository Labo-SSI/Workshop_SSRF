from flask import Flask, request, render_template_string, redirect
import requests
import time

app = Flask(__name__)

HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
  <head>
    <title>Enjoy</title>
  </head>
  <body>
    <h1>Welcome</h1>
    <a id="start-challenge" href="{{ url_for('test') }}">Start Challenge</a>
  </body>
</html>
"""

@app.route("/", methods=['GET'])
def index():
    return render_template_string(HTML_TEMPLATE)

@app.route("/test", methods=['GET'])
def test():
    referrer_url = request.referrer
    if referrer_url:
        try:
            if 'http://localhost:22' in referrer_url:
                referrer_url = 'http://nginx1:22'
            elif 'http://localhost:3306' in referrer_url:
                referrer_url = 'http://nginx2:3306'
            elif 'http://localhost:1900' in referrer_url:
                referrer_url = 'http://nginx3:1900'
            elif 'http://localhost:8888' in referrer_url:
                referrer_url = 'http://nginx4:8888'
            
            test = requests.get(referrer_url)
        except Exception as e:
            print(f"Error sending request: {e}")
            time.sleep(0.5)

    return "Test page"

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0')
