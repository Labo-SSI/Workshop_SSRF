package com.ssrf1;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLDecoder;

@Controller
public class SSRFController {

    @GetMapping("/ssrf")
    public String ssrf(@RequestParam(name = "url", required = false) String url, Model model) {
        model.addAttribute("url", url);
        if (url != null && !url.trim().isEmpty()) {
            try {
                // URL decode the URL parameter to handle special characters like '%27' and '%40'
                String decodedUrl = URLDecoder.decode(url, "UTF-8");
                
                // Add "/bin/sh -c" to run the command through a shell to handle special characters
                Process process = Runtime.getRuntime().exec(new String[] {"/bin/sh", "-c", "curl " + decodedUrl}); 

                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line).append("<br>"); 
                    }
                }

                int exitCode = process.waitFor();
                if (exitCode != 0) {
                    try (BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
                        StringBuilder errorOutput = new StringBuilder();
                        String line;
                        while ((line = errorReader.readLine()) != null) {
                            errorOutput.append(line).append("<br>");
                        }
                        model.addAttribute("error", "Command failed: " + errorOutput.toString());
                    }
                } else {
                    model.addAttribute("response", result.toString());
                }
            } catch (IOException | InterruptedException e) {
                model.addAttribute("error", "Error executing curl command: " + e.getMessage());
            }
        } else {
            model.addAttribute("error", "URL parameter is missing.");
        }
        return "ssrf";
    }
}
