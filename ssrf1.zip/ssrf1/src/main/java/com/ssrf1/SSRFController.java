package com.ssrf1;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

@Controller
public class SSRFController {

    @GetMapping("/ssrf")
    public String ssrf(@RequestParam(name="url", required=false) String url, Model model) {
        model.addAttribute("url", url);
        try {
            URL targetUrl = new URL(url);
            URLConnection connection = targetUrl.openConnection();

            StringBuilder result = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    result.append(line).append("\n");
                }
            } catch (IOException e) {
                model.addAttribute("error", "Invalid URL or network error.");
            }

            model.addAttribute("response", result.toString());
        } catch (Exception e) {
            model.addAttribute("error", "Invalid URL or unknown protocol.");
        }
        return "ssrf";
    }
}