package com.ssrf2.chat.chat;

public enum MessageType {
    CHAT,
    JOIN,
    LEAVE
}
