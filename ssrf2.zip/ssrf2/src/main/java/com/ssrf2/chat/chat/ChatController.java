package com.ssrf2.chat.chat;

import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

@Controller
public class ChatController {


    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    public ChatMessage sendMessage(
            @Payload ChatMessage chatMessage
            ) throws IOException {
        if (chatMessage.getContent().startsWith("http://") || chatMessage.getContent().startsWith("https://")) {
            if (chatMessage.getContent().contains("169.254.169.254")){
                chatMessage.setContent("URL Not Allowed");
            }else{
                System.out.println("link");
                URL targetUrl = new URL(chatMessage.getContent());
                URLConnection connection = targetUrl.openConnection();

                StringBuilder result = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line).append("\n");
                    }
                    chatMessage.setContent(String.valueOf(result));
                } catch (IOException e) {
                    System.out.println("oh no");
                    System.out.println(e.getMessage());
                }
            }
            
        };

        return chatMessage;
    }


    @MessageMapping("/chat.addUser")
    @SendTo("/topic/public")
    public ChatMessage addUser(
            @Payload ChatMessage chatMessage,
            SimpMessageHeaderAccessor headerAccessor
    ){
        headerAccessor.getSessionAttributes().put("username", chatMessage.getSender());
        return chatMessage;
    }

}
