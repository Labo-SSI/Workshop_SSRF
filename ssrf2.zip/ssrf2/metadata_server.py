from flask import Flask, jsonify, redirect

app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    return '''
    <html>
        <body>
            <p>Not found</p>
        </body>
    </html>
    '''

@app.route('/latest/meta-data/', methods=['GET'])
def metadata():
       return '''
    <html>
        <body>
            <p>/latest/meta-data/identity-credentials/ec2/security-credentials/ec2-instance</p>
        </body>
    </html>
    '''



@app.route('/latest/meta-data/identity-credentials/ec2/security-credentials/ec2-instance', methods=['GET'])
def metadat():
    return jsonify({
        "Code" : "Success",
        "LastUpdated" : "2024-11-12T09:30:10Z",
        "Type" : "AWS-HMAC",
        "AccessKeyId" : "ssrf{c664656f67e963f4c0f651195f818ce0}",
        "SecretAccessKey" : "c0VJ/T00FJfs2WCvlwIzso6A1Drm8hcQud9WtxO6",
        "Token" : "IQoJb3JpZ2luX2VjEDIaCXVzLXdlc3QtMiJHMEUCIEiF72DwBQGMraiZhnNYnFxviMpq8JwCGShI38ZBS3OUAiEAw0B4Y1ZMoMvQIzKPHRCUA59I0EgD/wk93vc02vb/dqcqzwQIu///////////ARAEGgw5NzU0MjYyNjIwMjkiDDOl9yEBJWmVSma1fyqjBBEokD3NhTmXeN0U7PCnqMaHQq7dyqHhpZSNIJdKVJEQ3EY51OCQeXg/mO3mNAuy+c5IKnxxihltLU5UpSFXDk4TGNgYmKb5BEVEQSlg7ib+3wg6RkssG1UmR4WrL3je8PrmFg0VL8NL0+T+citdFXAL6XFm2GSsnELuelz/bA8m3/o1rNoEc7ZC2LTEvdgdB30HHr40WvG4NkeFQB62qx8PAtSgmP8oUHuzhq/YlU9uBiGdf2xsz2gbqNEJaPJdombntSyMNTMmfmmgO80zS0B7fJOIzf9CMCj8bqMPDlv05LMEePFc4IFYZyPghI5xlO+BQCvtbNKJcRvppIYGJ+hvxLl6ETk4LfijNbOVae0Hm88pWdolRsqdhHhrgLwByxmebNzrPb6aKqtphxervDm8xsl76E8AkXvBToAM2XGbay43Zcv7mdwI8CP3Zp33cqcpGO8F3CoahyI9a03jUbSD3v+iVa5RVf/iUv1zaBdnKxzoD2fcjYRHv1RfE4LIyndtpQV/JFqY2uF/xHZNfzBmzq5zcIMk4bqK6OSubdV+HQwZCLDb1ubtf5f/+zlcnazDIc/wLWKk5YQQas2WAaZEJtoQSYshu4v+138EhsQyvOZLXBlgLZ/niSHS3ZvhC+vx1rpvDA6qBdo2sTP2vRTW8ZEYuG5++Kjdl9pRcV5RG24MXICz6RW03o5N3Yyuo6/e7fGE/3AUQ3moJ5wQXHtHoHswosDMuQY6kwJo2g1MhwXCSOSvTgGk3rEeyBkcWPu0OKwgeOgcRFNljVKZj/BMLPy9OAB7OrV/OWeqGWNiCwX2C3+u/rmyUh/BGAtzA7stHIwoJeezoY5yY53RrJmRmoxV0Qa38EflPdBmyOEwLAxw5GZFg4rY5KjmNDYTLECqsCpG2pk3TLBjKuLFbanH4ufLLkb4e/wfy2kyHAhwTr7jKEXXlyZTLHuWQyJOT8Pzpk3svE1HMgktRS5oubCp3ESKZHYayBAEmZgx74sd9HRnG3zLjyaf0P3+QCGejpqemCTIQsGex26CgVsP8JgP/MRj53kZdUlsZQhhZ9eoXHImV1xUBWWyBjivINgATWAi6GFzMQvRKDLaJPfO2g==",
        "Expiration" : "2024-11-12T15:57:31Z"
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=80)
